// Basic Mod Manager Support
// ToDo: Multiple Folders
// load order
const GAME_ID = "minecraftdungeons";
const MSAPP_ID = "Microsoft.Lovika.mod";
const MOD_FILE_EXT = ".pak";
const path = require('path');
const { fs, log, util } = require('vortex-api');
let jsonData = require(process.env.APPDATA + '/.minecraft_dungeons/launcher_settings.json');

function main(context) {
	context.registerGame({
		id: GAME_ID,
		name: 'Minecraft Dungeons',
		mergeMods: true,
		queryPath: findGame,
		supportedTools: [],
		queryModPath: () => 'Dungeons/Content/Paks/~mods',
		logo: 'gameart.jpg',
		executable: () => 'Dungeons/Binaries/Win64/Dungeons-Win64-Shipping.exe',
		requiredFiles: [
			'Dungeons/Binaries/Win64/Dungeons-Win64-Shipping.exe'
		],
		setup: prepareForModding,
		details: {
			microsoftAppID: MSAPP_ID,
			dungeonsid: GAME_ID,
		},
	});
	context.registerInstaller('mcdungeons-modinst','26', testSupportedContent, installContent);
	return true;
}

function findGame() {
try {

		// let rawdata = fs.readFileSync(process.env.APPDATA + '\.minecraft_dungeons\launcher_settings.json');
		//let jsonparseresult = JSON.parse(rawdata);
		// const instPath = jsonparseresult.productLibraryDir + "\dungeons\dungeons";
		return Promise.resolve(jsonData.productLibraryDir + "/dungeons/dungeons");

	} catch (err) {

	return util.GameStoreHelper.findByAppId([MSAPP_ID])
	.then(game => game.gamePath);

	}
}

function testSupportedContent(files, gameId) {
	let supported = (gameId === GAME_ID) &&
	(files.find(file => path.extname(file).toLowerCase() === MOD_FILE_EXT) !== undefined);

	if (supported && files.find(file => (path.basename(file).toLowerCase() === 'moduleconfig.xml') && (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
		supported = false;
	}


	return Promise.resolve({
		supported,
		requiredFiles: [],
	});
}

function installContent(files) {
	const modFile = files.find(file => path.extname(file).toLowerCase() === MOD_FILE_EXT);
	const idx = modFile.indexOf(path.basename(modFile));
	const rootPath = path.dirname(modFile);

	const filtered = files.filter(file => ((file.indexOf(rootPath) !== -1) && (!file.endsWith(path.sep))));

	const instructions = filtered.map(file => {
		return {
			type: 'copy',
			source: file,
			destination: path.join(file.substr(idx)),
		};
	});
	return Promise.resolve({ instructions });
}


function prepareForModding() {
	return true;
}


module.exports = {
	default: main,
};