// Basic Mod Manager Support
// ToDo: Multiple Folders
// load order
const GAME_ID = "minecraftdungeons";
const MSAPP_ID = "Microsoft.Lovika";
const MOD_FILE_EXT = ".pak";
const EXE_NAME = "Dungeons.exe";
const path = require('path');
const { fs, log, util } = require('vortex-api');
const modPath = path.join('Dungeons', 'Content', 'Paks', '~mods');
const _GAME_STORE_ID = "";

try {
	let jsonData = require(process.env.APPDATA + '/.minecraft_dungeons/launcher_settings.json');
} catch(err) {}

function main(context) {
	context.registerGame({
		id: GAME_ID,
		name: 'Minecraft Dungeons',
		mergeMods: true,
		queryPath: findGame,
		supportedTools: [],
		queryModPath: () => 'Dungeons/Content/Paks/~mods',
		requiresLauncher,
		logo: 'gameart.jpg',
		executable: () => EXE_NAME,
		requiredFiles: [
			'Dungeons/Content/Paks'
		],
		setup: prepareForModding,
		details: {
			microsoftAppID: MSAPP_ID,
			dungeonsid: GAME_ID,
		},
	});
	context.registerInstaller('mcdungeons-modinst','26', testSupportedContent, installContent);
	return true;
}

function findGame() {
try {

		// let rawdata = fs.readFileSync(process.env.APPDATA + '\.minecraft_dungeons\launcher_settings.json');
		//let jsonparseresult = JSON.parse(rawdata);
		// const instPath = jsonparseresult.productLibraryDir + "\dungeons\dungeons";
		return Promise.resolve(jsonData.productLibraryDir + "/dungeons/dungeons");

	} catch (err) {

	return util.GameStoreHelper.findByAppId([MSAPP_ID])
	.then(game => {game.gamePath});

	}
}

function testSupportedContent(files, gameId) {
	let supported = (gameId === GAME_ID) &&
	(files.find(file => path.extname(file).toLowerCase() === MOD_FILE_EXT) !== undefined);

	if (supported && files.find(file => (path.basename(file).toLowerCase() === 'moduleconfig.xml') && (path.basename(path.dirname(file)).toLowerCase() === 'fomod'))) {
		supported = false;
	}


	return Promise.resolve({
		supported,
		requiredFiles: [],
	});
}

async function requiresLauncher(gamePath) {
  // the windows store application has this silly permission system where we can't
  // even stat the files in the game directory, so if we can't stat the exe, it's a safe bet
  // we have to go through the launcher
  try {
    await fsOrig.stat(path.join(gamePath, EXE_NAME))
  } catch (err) {
    return {
        launcher: 'xbox',
        addInfo: {
          appId: MSAPP_ID,
          parameters: [
            { appExecName: 'Game' },
          ],
        }
    };
  }
}

function installContent(files) {
	const modFile = files.find(file => path.extname(file).toLowerCase() === MOD_FILE_EXT);
	const idx = modFile.indexOf(path.basename(modFile));
	const rootPath = path.dirname(modFile);

	const filtered = files.filter(file => ((file.indexOf(rootPath) !== -1) && (!file.endsWith(path.sep))));

	const instructions = filtered.map(file => {
		return {
			type: 'copy',
			source: file,
			destination: path.join(file.substr(idx)),
		};
	});
	return Promise.resolve({ instructions });
}


function prepareForModding(discovery) {

	try {
	const dir = fs.ensureDirWritableAsync(path.join(discovery.path, modPath));
	return Promise.resolve(dir);
	} catch (e) {
		throw new util.SetupError(readOnlyWarning())
	}
}

function readOnlyWarning() {
	return 'The script has failed to correctly patch the game,/n'
	+"or you have installed this extension without running the script first./n"
	+"Please run the script again! (If you do not have the script,You can get it at:/n"
	+"https://docs.dungeonsworkshop.net/gettingstarted"
}


module.exports = {
	default: main,
};